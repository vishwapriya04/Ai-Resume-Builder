'use client'

import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import ResumeBuilder from '@/components/resume-builder'
import ResumePreview from '@/components/resume-preview'
import FileUpload from '@/components/file-upload'
import { usePDFExport } from '@/hooks/use-pdf-export'
import { saveResume, loadResume, clearResume } from '@/lib/storage'
import { ResumeData } from '@/types/resume'
import { FileUp, FileText, Download, RotateCcw } from 'lucide-react'

const defaultResume: ResumeData = {
  personalInfo: {
    fullName: 'John Doe',
    email: 'john@example.com',
    phone: '(555) 123-4567',
    location: 'San Francisco, CA',
    summary: 'Professional with expertise in software development and team leadership',
  },
  experience: [
    {
      id: '1',
      company: 'Tech Company',
      position: 'Senior Developer',
      startDate: '2021',
      endDate: 'Present',
      description: 'Led development of microservices architecture',
    },
  ],
  education: [
    {
      id: '1',
      school: 'University of Technology',
      degree: 'Bachelor of Science',
      field: 'Computer Science',
      year: '2020',
    },
  ],
  skills: ['JavaScript', 'React', 'TypeScript', 'Node.js', 'Python'],
}

export default function Home() {
  const [resume, setResume] = useState<ResumeData>(defaultResume)
  const [activeTab, setActiveTab] = useState('input')
  const { exportToPDF } = usePDFExport()
  const [mounted, setMounted] = useState(false)

  // Load saved resume on mount
  useEffect(() => {
    setMounted(true)
    const saved = loadResume()
    if (saved) {
      setResume(saved)
    }
  }, [])

  const handleResumeChange = (updated: ResumeData) => {
    setResume(updated)
    // Auto-save after short delay
    setTimeout(() => {
      saveResume(updated)
    }, 500)
  }

  const handleResumeLoad = (loaded: Partial<ResumeData>) => {
    setResume({
      ...resume,
      ...loaded,
      experience: loaded.experience || resume.experience,
      education: loaded.education || resume.education,
      skills: loaded.skills || resume.skills,
    })
    setActiveTab('input')
  }

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-primary">Resume Builder</h1>
              <p className="text-sm text-muted-foreground">
                Powered by AI for professional results
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                className="gap-2"
                onClick={() => exportToPDF(resume, `${resume.personalInfo.fullName}-resume.pdf`)}
              >
                <Download className="w-4 h-4" />
                Export as PDF
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  clearResume()
                  setResume(defaultResume)
                }}
                title="Clear all data"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="input" className="gap-2">
              <FileText className="w-4 h-4" />
              Input
            </TabsTrigger>
            <TabsTrigger value="preview" className="gap-2">
              <FileText className="w-4 h-4" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="upload" className="gap-2">
              <FileUp className="w-4 h-4" />
              Import
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="space-y-6">
            <ResumeBuilder resume={resume} onResumeChange={handleResumeChange} />
          </TabsContent>

          <TabsContent value="preview" className="space-y-6">
            <ResumePreview resume={resume} />
          </TabsContent>

          <TabsContent value="upload" className="space-y-6">
            <FileUpload onResumeLoad={handleResumeLoad} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
