import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { text, section } = await req.json()

    if (!text || !section) {
      return NextResponse.json(
        { error: 'Missing text or section' },
        { status: 400 }
      )
    }

    // Placeholder suggestions - will be replaced with actual AI API calls
    const suggestions = generateSuggestions(text, section)

    return NextResponse.json({ suggestions })
  } catch (error) {
    console.error('API error:', error)
    return NextResponse.json(
      { error: 'Failed to generate suggestions' },
      { status: 500 }
    )
  }
}

function generateSuggestions(text: string, section: string): string[] {
  const suggestions: string[] = []

  // Generic suggestions based on section
  if (section === 'summary' || section.includes('experience')) {
    suggestions.push(
      'Consider adding specific metrics and measurable achievements',
      'Use action verbs to start your bullet points',
      'Quantify your impact when possible (e.g., "increased by 50%")'
    )
  } else if (section === 'skills') {
    suggestions.push(
      'Group related skills together',
      'Prioritize skills most relevant to your target role',
      'Consider adding proficiency levels if applicable'
    )
  } else if (section === 'education') {
    suggestions.push(
      'Add relevant coursework or honors if space permits',
      'Include GPA if 3.5 or above',
      'Mention relevant projects or thesis work'
    )
  }

  return suggestions.slice(0, 3)
}
