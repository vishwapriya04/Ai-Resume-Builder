'use client'

import { ResumeData } from '@/types/resume'

export function usePDFExport() {
  const exportToPDF = (resume: ResumeData, filename: string = 'resume.pdf') => {
    // Get the preview content element
    const content = document.getElementById('preview-content')
    if (!content) {
      console.error('Preview content not found')
      return
    }

    // Create a print window
    const printWindow = window.open('', '', 'height=600,width=800')
    if (!printWindow) {
      console.error('Failed to open print window')
      return
    }

    // Clone the content to avoid modifying the original
    const clonedContent = content.cloneNode(true) as HTMLElement

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${resume.personalInfo.fullName} - Resume</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
              'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
              sans-serif;
            line-height: 1.6;
            color: #1a1a1a;
            background: white;
            padding: 40px;
            max-width: 8.5in;
            margin: 0 auto;
          }
          
          @media print {
            body {
              padding: 0.5in;
            }
          }
          
          h1 {
            font-size: 28px;
            font-weight: 700;
            color: #4f46e5;
            margin-bottom: 8px;
            border-bottom: 3px solid #4f46e5;
            padding-bottom: 12px;
          }
          
          h2 {
            font-size: 14px;
            font-weight: 700;
            color: #4f46e5;
            margin-top: 20px;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 6px;
          }
          
          .contact {
            font-size: 11px;
            color: #666;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
          }
          
          .contact span {
            display: flex;
            align-items: center;
          }
          
          .section {
            margin-bottom: 16px;
          }
          
          .summary {
            font-size: 13px;
            line-height: 1.6;
            color: #374151;
          }
          
          .experience-item,
          .education-item {
            margin-bottom: 12px;
          }
          
          .experience-item h3,
          .education-item h3 {
            font-size: 13px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 4px;
          }
          
          .experience-item .company,
          .education-item .school {
            font-size: 12px;
            color: #6b7280;
            margin-bottom: 4px;
          }
          
          .date {
            font-size: 11px;
            color: #9ca3af;
            float: right;
          }
          
          .description {
            font-size: 12px;
            color: #374151;
            line-height: 1.5;
            margin-top: 6px;
          }
          
          .skills {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            font-size: 12px;
          }
          
          .skill-tag {
            background-color: #e0e7ff;
            color: #4f46e5;
            padding: 4px 10px;
            border-radius: 4px;
            display: inline-block;
          }
        </style>
      </head>
      <body>
        <h1>${resume.personalInfo.fullName}</h1>
        <div class="contact">
          ${resume.personalInfo.email ? `<span>${resume.personalInfo.email}</span>` : ''}
          ${resume.personalInfo.phone ? `<span>${resume.personalInfo.phone}</span>` : ''}
          ${resume.personalInfo.location ? `<span>${resume.personalInfo.location}</span>` : ''}
        </div>
        
        ${
          resume.personalInfo.summary
            ? `
          <div class="section">
            <h2>Professional Summary</h2>
            <p class="summary">${resume.personalInfo.summary}</p>
          </div>
        `
            : ''
        }
        
        ${
          resume.experience.length > 0
            ? `
          <div class="section">
            <h2>Professional Experience</h2>
            ${resume.experience
              .map(
                (exp) => `
              <div class="experience-item">
                <div style="display: flex; justify-content: space-between;">
                  <h3>${exp.position}</h3>
                  <span class="date">${exp.startDate}${exp.endDate ? ` - ${exp.endDate}` : ''}</span>
                </div>
                <div class="company">${exp.company}</div>
                <div class="description">${exp.description}</div>
              </div>
            `
              )
              .join('')}
          </div>
        `
            : ''
        }
        
        ${
          resume.education.length > 0
            ? `
          <div class="section">
            <h2>Education</h2>
            ${resume.education
              .map(
                (edu) => `
              <div class="education-item">
                <div style="display: flex; justify-content: space-between;">
                  <h3>${edu.degree}${edu.field ? ` in ${edu.field}` : ''}</h3>
                  ${edu.year ? `<span class="date">${edu.year}</span>` : ''}
                </div>
                <div class="school">${edu.school}</div>
              </div>
            `
              )
              .join('')}
          </div>
        `
            : ''
        }
        
        ${
          resume.skills.length > 0
            ? `
          <div class="section">
            <h2>Skills</h2>
            <div class="skills">
              ${resume.skills.map((skill) => `<span class="skill-tag">${skill}</span>`).join('')}
            </div>
          </div>
        `
            : ''
        }
      </body>
      </html>
    `

    printWindow.document.write(htmlContent)
    printWindow.document.close()

    // Wait for content to load before printing
    printWindow.onload = () => {
      printWindow.print()
    }
  }

  return { exportToPDF }
}
