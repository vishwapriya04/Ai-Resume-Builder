import { ResumeData } from '@/types/resume'

const STORAGE_KEY = 'resume-builder-data'

export function saveResume(resume: ResumeData): void {
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(resume))
    }
  } catch (error) {
    console.error('Failed to save resume:', error)
  }
}

export function loadResume(): ResumeData | null {
  try {
    if (typeof window !== 'undefined') {
      const data = localStorage.getItem(STORAGE_KEY)
      return data ? JSON.parse(data) : null
    }
  } catch (error) {
    console.error('Failed to load resume:', error)
  }
  return null
}

export function clearResume(): void {
  try {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY)
    }
  } catch (error) {
    console.error('Failed to clear resume:', error)
  }
}
