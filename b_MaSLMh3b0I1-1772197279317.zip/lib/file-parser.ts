import { ResumeData } from '@/types/resume'

export async function parseResume(file: File): Promise<Partial<ResumeData>> {
  const text = await extractTextFromFile(file)
  return parseResumeText(text)
}

async function extractTextFromFile(file: File): Promise<string> {
  if (file.type === 'text/plain') {
    return await file.text()
  } else if (
    file.type === 'application/pdf' ||
    file.name.endsWith('.pdf')
  ) {
    // For PDF parsing, we would need a library like pdfjs-dist
    // For now, return placeholder
    console.log('PDF parsing requires additional library')
    return ''
  } else if (
    file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    file.name.endsWith('.docx')
  ) {
    // For DOCX parsing, we would need a library like docx-parser
    // For now, return placeholder
    console.log('DOCX parsing requires additional library')
    return ''
  }
  return ''
}

function parseResumeText(text: string): Partial<ResumeData> {
  const lines = text.split('\n').filter((line) => line.trim())

  const resume: Partial<ResumeData> = {
    personalInfo: {
      fullName: '',
      email: '',
      phone: '',
      location: '',
      summary: '',
    },
    experience: [],
    education: [],
    skills: [],
  }

  let currentSection = ''

  for (const line of lines) {
    const trimmedLine = line.trim().toUpperCase()

    // Detect sections
    if (
      trimmedLine.includes('SUMMARY') ||
      trimmedLine.includes('OBJECTIVE')
    ) {
      currentSection = 'summary'
    } else if (trimmedLine.includes('EXPERIENCE') || trimmedLine.includes('EMPLOYMENT')) {
      currentSection = 'experience'
    } else if (trimmedLine.includes('EDUCATION')) {
      currentSection = 'education'
    } else if (trimmedLine.includes('SKILL')) {
      currentSection = 'skills'
    } else if (trimmedLine.includes('CONTACT') || trimmedLine.includes('PERSONAL')) {
      currentSection = 'personal'
    } else if (currentSection === 'summary' && line.trim()) {
      if (resume.personalInfo) {
        resume.personalInfo.summary += line + ' '
      }
    } else if (currentSection === 'skills' && line.trim()) {
      const skillItems = line
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s)
      resume.skills = [...(resume.skills || []), ...skillItems]
    }
  }

  // Extract contact info patterns
  const emailMatch = text.match(/[\w\.-]+@[\w\.-]+\.\w+/)
  if (emailMatch && resume.personalInfo) {
    resume.personalInfo.email = emailMatch[0]
  }

  const phoneMatch = text.match(/\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/)
  if (phoneMatch && resume.personalInfo) {
    resume.personalInfo.phone = phoneMatch[0]
  }

  return resume
}

export function generatePDF(resume: ResumeData): void {
  // Placeholder for PDF generation
  // In production, would use a library like jsPDF or html2pdf
  const htmlContent = generateHTMLResume(resume)
  const printWindow = window.open('', '', 'height=400,width=600')
  if (printWindow) {
    printWindow.document.write(htmlContent)
    printWindow.document.close()
    printWindow.print()
  }
}

function generateHTMLResume(resume: ResumeData): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>${resume.personalInfo.fullName} - Resume</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; margin: 20px; }
        h1 { color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
        h2 { color: #555; margin-top: 20px; margin-bottom: 10px; }
        .contact { font-size: 12px; color: #666; }
        .section { margin-bottom: 15px; }
      </style>
    </head>
    <body>
      <h1>${resume.personalInfo.fullName}</h1>
      <div class="contact">
        ${resume.personalInfo.email} | ${resume.personalInfo.phone} | ${resume.personalInfo.location}
      </div>
      <div class="section">
        <h2>Professional Summary</h2>
        <p>${resume.personalInfo.summary}</p>
      </div>
      <div class="section">
        <h2>Experience</h2>
        ${resume.experience.map((exp) => `
          <div>
            <strong>${exp.position}</strong> - ${exp.company} (${exp.startDate} - ${exp.endDate})
            <p>${exp.description}</p>
          </div>
        `).join('')}
      </div>
      <div class="section">
        <h2>Education</h2>
        ${resume.education.map((edu) => `
          <div>
            <strong>${edu.degree} in ${edu.field}</strong> - ${edu.school} (${edu.year})
          </div>
        `).join('')}
      </div>
      <div class="section">
        <h2>Skills</h2>
        <p>${resume.skills.join(', ')}</p>
      </div>
    </body>
    </html>
  `
}
