import { AIResponse } from '@/types/resume'

export async function fetchAISuggestions(
  text: string,
  section: string
): Promise<AIResponse[]> {
  try {
    const response = await fetch('/api/suggestions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text, section }),
    })

    if (!response.ok) {
      throw new Error('Failed to fetch suggestions')
    }

    const data = await response.json()
    return data.suggestions.map((suggestion: string) => ({
      suggestion,
      category: 'improvement' as const,
    }))
  } catch (error) {
    console.error('Error fetching AI suggestions:', error)
    // Return placeholder suggestions on error
    return getPlaceholderSuggestions(section)
  }
}

function getPlaceholderSuggestions(section: string): AIResponse[] {
  const suggestions: Record<string, AIResponse[]> = {
    summary: [
      {
        suggestion: 'Use specific metrics and measurable achievements',
        category: 'improvement',
      },
      {
        suggestion: 'Start with action verbs to make your summary more impactful',
        category: 'improvement',
      },
    ],
    experience: [
      {
        suggestion: 'Quantify your impact with specific numbers or percentages',
        category: 'improvement',
      },
      {
        suggestion: 'Focus on outcomes and results, not just responsibilities',
        category: 'improvement',
      },
      {
        suggestion: 'Use strong action verbs: Led, Managed, Improved, Increased',
        category: 'improvement',
      },
    ],
    skills: [
      {
        suggestion: 'Group related skills together for better organization',
        category: 'improvement',
      },
      {
        suggestion: 'Prioritize skills most relevant to your target role',
        category: 'improvement',
      },
    ],
    education: [
      {
        suggestion: 'Include relevant coursework or honors if applicable',
        category: 'improvement',
      },
      {
        suggestion: 'Add GPA if 3.5 or above',
        category: 'improvement',
      },
    ],
  }

  return suggestions[section] || suggestions.experience
}
