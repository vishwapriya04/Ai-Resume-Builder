export interface PersonalInfo {
  fullName: string
  email: string
  phone: string
  location: string
  summary: string
}

export interface Experience {
  id: string
  company: string
  position: string
  startDate: string
  endDate: string
  description: string
}

export interface Education {
  id: string
  school: string
  degree: string
  field: string
  year: string
}

export interface ResumeData {
  personalInfo: PersonalInfo
  experience: Experience[]
  education: Education[]
  skills: string[]
}

export interface AIResponse {
  suggestion: string
  category: 'bullet' | 'skill' | 'improvement'
}
