'use client'

import { ResumeData } from '@/types/resume'
import { Card } from '@/components/ui/card'

interface ResumePreviewProps {
  resume: ResumeData
}

export default function ResumePreview({ resume }: ResumePreviewProps) {
  return (
    <div className="max-w-4xl mx-auto">
      <Card className="p-8 bg-white text-black print:shadow-none print:border-none">
        <div id="preview-content" className="space-y-6">
          {/* Header */}
          <div className="border-b-2 border-primary pb-6">
            <h1 className="text-4xl font-bold text-primary">
              {resume.personalInfo.fullName}
            </h1>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600 mt-2">
              {resume.personalInfo.email && (
                <span>{resume.personalInfo.email}</span>
              )}
              {resume.personalInfo.phone && (
                <span>{resume.personalInfo.phone}</span>
              )}
              {resume.personalInfo.location && (
                <span>{resume.personalInfo.location}</span>
              )}
            </div>
          </div>

          {/* Summary */}
          {resume.personalInfo.summary && (
            <div>
              <h2 className="text-xl font-bold text-primary mb-3 uppercase tracking-wide">
                Professional Summary
              </h2>
              <p className="text-gray-700 leading-relaxed">
                {resume.personalInfo.summary}
              </p>
            </div>
          )}

          {/* Experience */}
          {resume.experience.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-primary mb-4 uppercase tracking-wide">
                Experience
              </h2>
              <div className="space-y-4">
                {resume.experience.map((exp) => (
                  <div key={exp.id}>
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {exp.position}
                      </h3>
                      <span className="text-sm text-gray-600">
                        {exp.startDate}
                        {exp.endDate && exp.endDate !== 'Present' ? ` – ${exp.endDate}` : exp.endDate ? ` – ${exp.endDate}` : ''}
                      </span>
                    </div>
                    <p className="text-gray-600 font-medium">{exp.company}</p>
                    <p className="text-gray-700 mt-2 leading-relaxed">
                      {exp.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {resume.education.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-primary mb-4 uppercase tracking-wide">
                Education
              </h2>
              <div className="space-y-3">
                {resume.education.map((edu) => (
                  <div key={edu.id}>
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {edu.degree}
                        {edu.field && ` in ${edu.field}`}
                      </h3>
                      {edu.year && (
                        <span className="text-sm text-gray-600">{edu.year}</span>
                      )}
                    </div>
                    <p className="text-gray-600">{edu.school}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          {resume.skills.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-primary mb-3 uppercase tracking-wide">
                Skills
              </h2>
              <div className="flex flex-wrap gap-2">
                {resume.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="bg-secondary text-secondary-foreground px-3 py-1 rounded text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Print Styles */}
      <style jsx>{`
        @media print {
          body {
            margin: 0;
            padding: 0;
          }
          #preview-content {
            color: black;
            background: white;
          }
        }
      `}</style>
    </div>
  )
}
