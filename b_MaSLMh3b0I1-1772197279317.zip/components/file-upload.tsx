'use client'

import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ResumeData } from '@/types/resume'
import { parseResume } from '@/lib/file-parser'
import { FileUp, CheckCircle, AlertCircle } from 'lucide-react'

interface FileUploadProps {
  onResumeLoad: (resume: Partial<ResumeData>) => void
}

export default function FileUpload({ onResumeLoad }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle')
  const [message, setMessage] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    const files = e.dataTransfer.files
    if (files.length > 0) {
      await processFile(files[0])
    }
  }

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files
    if (files && files.length > 0) {
      await processFile(files[0])
    }
  }

  const processFile = async (file: File) => {
    setIsLoading(true)
    setStatus('idle')
    setMessage('')

    try {
      // Validate file type
      const validTypes = [
        'text/plain',
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      ]

      if (!validTypes.includes(file.type) && !file.name.match(/\.(txt|pdf|docx)$/i)) {
        throw new Error('Unsupported file type. Please use TXT, PDF, or DOCX.')
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        throw new Error('File size exceeds 5MB limit.')
      }

      const resumeData = await parseResume(file)
      onResumeLoad(resumeData)

      setStatus('success')
      setMessage(`Successfully imported resume from ${file.name}`)
    } catch (error) {
      setStatus('error')
      setMessage(
        error instanceof Error ? error.message : 'Failed to parse resume file'
      )
    } finally {
      setIsLoading(false)
    }
  }

  const processTextInput = async (text: string) => {
    setIsLoading(true)
    setStatus('idle')
    setMessage('')

    try {
      if (!text.trim()) {
        throw new Error('Please paste some text first.')
      }

      const resumeData = await parseResume(new File([text], 'resume.txt', { type: 'text/plain' }))
      onResumeLoad(resumeData)

      setStatus('success')
      setMessage('Successfully imported resume from pasted text')
    } catch (error) {
      setStatus('error')
      setMessage(
        error instanceof Error ? error.message : 'Failed to parse resume text'
      )
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Import from File</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Drag and Drop Zone */}
        <div
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
            isDragging
              ? 'border-primary bg-primary/5'
              : 'border-border'
          }`}
        >
          <FileUp className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-semibold mb-2">
            Drop your resume here
          </h3>
          <p className="text-sm text-muted-foreground mb-6">
            or click the button below to select a file
          </p>
          <p className="text-xs text-muted-foreground mb-6">
            Supports: PDF, Word (.docx), and plain text (.txt) • Max 5MB
          </p>

          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.pdf,.docx,text/plain,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            onChange={handleFileSelect}
            className="hidden"
          />

          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="gap-2"
          >
            {isLoading ? 'Processing...' : 'Choose File'}
          </Button>
        </div>

        {/* Status Messages */}
        {status === 'success' && (
          <div className="flex items-start gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-green-900">Success</p>
              <p className="text-sm text-green-700">{message}</p>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-900">Error</p>
              <p className="text-sm text-red-700">{message}</p>
            </div>
          </div>
        )}

        {/* Text Paste Option */}
        <div className="mt-6 border-t pt-6">
          <h4 className="font-semibold mb-4">Or paste your resume text</h4>
          <TextPasteInput onPaste={processTextInput} disabled={isLoading} />
        </div>
      </CardContent>
    </Card>
  )
}

interface TextPasteInputProps {
  onPaste: (text: string) => void
  disabled: boolean
}

function TextPasteInput({ onPaste, disabled }: TextPasteInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handlePaste = () => {
    const text = textareaRef.current?.value
    if (text && text.trim()) {
      onPaste(text)
      if (textareaRef.current) {
        textareaRef.current.value = ''
      }
    }
  }

  return (
    <div className="space-y-3">
      <textarea
        ref={textareaRef}
        placeholder="Paste your resume text here..."
        className="w-full h-32 p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
        disabled={disabled}
      />
      <Button
        onClick={handlePaste}
        disabled={disabled}
        className="w-full"
      >
        Import Text
      </Button>
    </div>
  )
}
