'use client'

import { useState } from 'react'
import { ResumeData, Experience, Education } from '@/types/resume'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Plus, Trash2, Sparkles } from 'lucide-react'
import { v4 as uuidv4 } from 'uuid'
import { fetchAISuggestions } from '@/lib/ai-client'

interface ResumeBuilderProps {
  resume: ResumeData
  onResumeChange: (resume: ResumeData) => void
}

export default function ResumeBuilder({
  resume,
  onResumeChange,
}: ResumeBuilderProps) {
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [loadingSection, setLoadingSection] = useState<string | null>(null)

  const updatePersonalInfo = (field: keyof typeof resume.personalInfo, value: string) => {
    onResumeChange({
      ...resume,
      personalInfo: {
        ...resume.personalInfo,
        [field]: value,
      },
    })
  }

  const addExperience = () => {
    const newExperience: Experience = {
      id: uuidv4(),
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      description: '',
    }
    onResumeChange({
      ...resume,
      experience: [...resume.experience, newExperience],
    })
  }

  const updateExperience = (id: string, field: keyof Experience, value: string) => {
    onResumeChange({
      ...resume,
      experience: resume.experience.map((exp) =>
        exp.id === id ? { ...exp, [field]: value } : exp
      ),
    })
  }

  const removeExperience = (id: string) => {
    onResumeChange({
      ...resume,
      experience: resume.experience.filter((exp) => exp.id !== id),
    })
  }

  const addEducation = () => {
    const newEducation: Education = {
      id: uuidv4(),
      school: '',
      degree: '',
      field: '',
      year: '',
    }
    onResumeChange({
      ...resume,
      education: [...resume.education, newEducation],
    })
  }

  const updateEducation = (id: string, field: keyof Education, value: string) => {
    onResumeChange({
      ...resume,
      education: resume.education.map((edu) =>
        edu.id === id ? { ...edu, [field]: value } : edu
      ),
    })
  }

  const removeEducation = (id: string) => {
    onResumeChange({
      ...resume,
      education: resume.education.filter((edu) => edu.id !== id),
    })
  }

  const updateSkills = (skills: string[]) => {
    onResumeChange({
      ...resume,
      skills,
    })
  }

  const generateSuggestions = async (text: string, section: string) => {
    if (!text.trim()) return

    setLoadingSection(section)
    try {
      const responses = await fetchAISuggestions(text, section)
      setSuggestions(responses.map((r) => r.suggestion))
    } catch (error) {
      console.error('Failed to generate suggestions:', error)
      setSuggestions([
        'Tip: Add specific metrics and measurable outcomes',
        'Suggestion: Use strong action verbs',
      ])
    } finally {
      setLoadingSection(null)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="personal" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="personal">Personal</TabsTrigger>
          <TabsTrigger value="experience">Experience</TabsTrigger>
          <TabsTrigger value="education">Education</TabsTrigger>
          <TabsTrigger value="skills">Skills</TabsTrigger>
        </TabsList>

        {/* Personal Info */}
        <TabsContent value="personal">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Full Name</Label>
                  <Input
                    value={resume.personalInfo.fullName}
                    onChange={(e) => updatePersonalInfo('fullName', e.target.value)}
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <Label>Email</Label>
                  <Input
                    value={resume.personalInfo.email}
                    onChange={(e) => updatePersonalInfo('email', e.target.value)}
                    placeholder="john@example.com"
                    type="email"
                  />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input
                    value={resume.personalInfo.phone}
                    onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div>
                  <Label>Location</Label>
                  <Input
                    value={resume.personalInfo.location}
                    onChange={(e) => updatePersonalInfo('location', e.target.value)}
                    placeholder="San Francisco, CA"
                  />
                </div>
              </div>
              <div>
                <Label>Professional Summary</Label>
                <Textarea
                  value={resume.personalInfo.summary}
                  onChange={(e) => updatePersonalInfo('summary', e.target.value)}
                  placeholder="Brief professional summary"
                  rows={3}
                />
              </div>
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => generateSuggestions(resume.personalInfo.summary, 'summary')}
                disabled={loadingSection === 'summary'}
              >
                <Sparkles className="w-4 h-4" />
                {loadingSection === 'summary' ? 'Generating...' : 'Get AI Suggestions'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Experience */}
        <TabsContent value="experience" className="space-y-4">
          {resume.experience.map((exp, index) => (
            <Card key={exp.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle className="text-lg">Experience {index + 1}</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeExperience(exp.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Company</Label>
                    <Input
                      value={exp.company}
                      onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                      placeholder="Company name"
                    />
                  </div>
                  <div>
                    <Label>Position</Label>
                    <Input
                      value={exp.position}
                      onChange={(e) => updateExperience(exp.id, 'position', e.target.value)}
                      placeholder="Job title"
                    />
                  </div>
                  <div>
                    <Label>Start Date</Label>
                    <Input
                      value={exp.startDate}
                      onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                      placeholder="2020"
                    />
                  </div>
                  <div>
                    <Label>End Date</Label>
                    <Input
                      value={exp.endDate}
                      onChange={(e) => updateExperience(exp.id, 'endDate', e.target.value)}
                      placeholder="2024"
                    />
                  </div>
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={exp.description}
                    onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                    placeholder="Describe your responsibilities and achievements"
                    rows={3}
                  />
                </div>
                <Button
                  variant="outline"
                  className="gap-2"
                  onClick={() => generateSuggestions(exp.description, `experience-${exp.id}`)}
                  disabled={loadingSection === `experience-${exp.id}`}
                >
                  <Sparkles className="w-4 h-4" />
                  {loadingSection === `experience-${exp.id}` ? 'Generating...' : 'Improve with AI'}
                </Button>
              </CardContent>
            </Card>
          ))}
          <Button onClick={addExperience} variant="outline" className="w-full gap-2">
            <Plus className="w-4 h-4" />
            Add Experience
          </Button>
        </TabsContent>

        {/* Education */}
        <TabsContent value="education" className="space-y-4">
          {resume.education.map((edu, index) => (
            <Card key={edu.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle className="text-lg">Education {index + 1}</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeEducation(edu.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>School/University</Label>
                    <Input
                      value={edu.school}
                      onChange={(e) => updateEducation(edu.id, 'school', e.target.value)}
                      placeholder="School name"
                    />
                  </div>
                  <div>
                    <Label>Degree</Label>
                    <Input
                      value={edu.degree}
                      onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)}
                      placeholder="Bachelor of Science"
                    />
                  </div>
                  <div>
                    <Label>Field of Study</Label>
                    <Input
                      value={edu.field}
                      onChange={(e) => updateEducation(edu.id, 'field', e.target.value)}
                      placeholder="Computer Science"
                    />
                  </div>
                  <div>
                    <Label>Graduation Year</Label>
                    <Input
                      value={edu.year}
                      onChange={(e) => updateEducation(edu.id, 'year', e.target.value)}
                      placeholder="2020"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          <Button onClick={addEducation} variant="outline" className="w-full gap-2">
            <Plus className="w-4 h-4" />
            Add Education
          </Button>
        </TabsContent>

        {/* Skills */}
        <TabsContent value="skills">
          <Card>
            <CardHeader>
              <CardTitle>Skills</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Skills (comma-separated)</Label>
                <Textarea
                  value={resume.skills.join(', ')}
                  onChange={(e) => updateSkills(e.target.value.split(',').map((s) => s.trim()))}
                  placeholder="JavaScript, React, TypeScript, Node.js"
                  rows={4}
                />
              </div>
              <div className="flex flex-wrap gap-2">
                {resume.skills.map((skill, index) => (
                  <div
                    key={index}
                    className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm flex items-center gap-2"
                  >
                    {skill}
                    <button
                      onClick={() => {
                        updateSkills(resume.skills.filter((_, i) => i !== index))
                      }}
                      className="hover:opacity-70"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => generateSuggestions(resume.skills.join(', '), 'skills')}
                disabled={loadingSection === 'skills'}
              >
                <Sparkles className="w-4 h-4" />
                {loadingSection === 'skills' ? 'Generating...' : 'Suggest Skills'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <Card className="bg-secondary border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="w-5 h-5 text-accent" />
              AI Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {suggestions.map((suggestion, index) => (
                <li
                  key={index}
                  className="flex items-start gap-3 text-sm"
                >
                  <span className="text-accent font-semibold">→</span>
                  <span>{suggestion}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
